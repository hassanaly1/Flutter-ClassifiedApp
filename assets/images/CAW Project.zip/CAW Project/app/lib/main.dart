import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _splash = true, _loading = true, _isCartPage = false, _closeApp = false;
  final homeUrl = 'https://cantonautowash.mywashaccount.com/';
  final _controller = WebViewController()
    ..setBackgroundColor(Colors.white)
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..canGoBack();

  @override
  void initState() {
    Future.delayed(const Duration(seconds: 4))
        .then((_) => setState(() => _splash = false));
    _controller.loadRequest(Uri.parse(homeUrl));
    _controller.setNavigationDelegate(
      NavigationDelegate(
        onPageFinished: (url) async {
          await _controller.runJavaScript('''
              document.querySelector('.client-logo-nav-bar').style.display = 'none';
              document.querySelector('.ecomm-navbar #btn-mobile-menu-toggle').style.display = 'none';
              document.querySelector('.ecomm-navbar-btns').style.display = 'none';
              var element = document.querySelector('.ecomm-navbar.sticky-to-bottom.hidden-sm-lg');
              if (element) { element.parentNode.removeChild(element); }
            ''');
          setState(() => _loading = false);
        },
        onUrlChange: (url) {
          setState(() => _loading = true);
        },
        onPageStarted: (url) => setState(() => _isCartPage = (url != homeUrl)),
      ),
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PopScope(
        canPop: _closeApp,
        onPopInvoked: (_) {
          if (!_closeApp) {
            setState(() => _closeApp = true);
            Future.delayed(const Duration(seconds: 2))
                .then((_) => setState(() => _closeApp = false));
          }
        },
        child: SafeArea(
          child: Scaffold(
            body: _splash
                ? Center(
                    child: TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.0, end: 1.0),
                    duration: const Duration(milliseconds: 750),
                    builder: (context, scale, child) => Transform.scale(
                      scale: scale,
                      child: Image.asset(
                        'assets/logo.png',
                      ),
                    ),
                  ))
                : Stack(
                    children: [
                      WebViewWidget(controller: _controller),
                      if (_loading)
                        ColoredBox(
                          color: _loading ? Colors.white : Colors.transparent,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Column(
                                    children: [
                                      Image.asset('assets/logo.png'),
                                      const SizedBox(height: 16.0),
                                      LoadingAnimationWidget.threeRotatingDots(
                                        color: const Color(0xFF252525)
                                            .withOpacity(0.75),
                                        size: 50,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      Container(
                        color: _loading
                            ? const Color(0xFF252525)
                            : Colors.transparent,
                        width: _loading
                            ? double.infinity
                            : MediaQuery.of(context).size.width * 0.75,
                        padding: const EdgeInsets.only(left: 16.0),
                        height: kToolbarHeight * 1.18,
                        child: const Row(
                          children: [
                            Text(
                              'Canton Auto Wash',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                fontSize: 20,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_isCartPage && !_loading)
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            color: const Color(0xFF252525),
                            height: kToolbarHeight * 1.30,
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                InkWell(
                                  onTap: () async {
                                    setState(() => _loading = true);
                                    _controller.loadRequest(Uri.parse(homeUrl));
                                  },
                                  child: const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Text(
                                      'Home',
                                      textAlign: TextAlign.start,
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
